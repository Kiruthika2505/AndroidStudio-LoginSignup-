package com.mobilehybrid.openup.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mobilehybrid.openup.R;
import com.mobilehybrid.openup.databinding.ActivityLoginBinding;
import com.mobilehybrid.openup.helpers.InputValidation;
import com.mobilehybrid.openup.helpers.SharePrefConfig;
import com.mobilehybrid.openup.models.User;
import com.mobilehybrid.openup.sqlpart.DatabaseHelper;

public class Login extends AppCompatActivity {

    AppCompatActivity activity = Login.this;
    ActivityLoginBinding binding;
    private InputValidation inputValidation;
    private DatabaseHelper databaseHelper;

    SharePrefConfig sharePrefConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_login);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        sharePrefConfig = new SharePrefConfig(activity);
        initObjects();

        binding.appCompatButtonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (binding.textInputEditTextEmail.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter a valid email", Toast.LENGTH_SHORT).show();

                } else if (binding.textInputEditTextPassword.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter Password", Toast.LENGTH_SHORT).show();

                } else {
                    verifyFromSQLite();
                }
                InputMethodManager imm = (InputMethodManager) getSystemService(
                        Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(binding.appCompatButtonLogin.getWindowToken(), 0);
                //verifyFromSQLite();
            }
        });
        binding.textViewLinkRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this, Signup.class);
                startActivity(i);
            }
        });
        binding.textViewLinkForgotpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showForgotPasswordDialog();
            }
        });
    }

    private void initObjects() {
        databaseHelper = new DatabaseHelper(activity);
        inputValidation = new InputValidation(activity);
    }

    /**
     * This method is to validate the input text fields and verify login credentials from SQLite
     */
    private void verifyFromSQLite() {
        String email = binding.textInputEditTextEmail.getText().toString().trim();
        String password = binding.textInputEditTextPassword.getText().toString().trim();

        if (!inputValidation.isInputEditTextFilled(binding.textInputEditTextEmail, binding.textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextEmail(binding.textInputEditTextEmail, binding.textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(binding.textInputEditTextPassword, binding.textInputLayoutPassword, getString(R.string.error_message_email))) {
            return;
        }
        if (databaseHelper.checkUser(email, password)) {
            Intent accountsIntent = new Intent(activity, MainActivity.class);
            accountsIntent.putExtra("EMAIL", email);
            emptyInputEditText();
            sharePrefConfig.SetIsloogedIn(true);
            sharePrefConfig.setUser_email(email);
            startActivity(accountsIntent);
        } else {
            // Snack Bar to show success message that record is wrong
            Snackbar.make(binding.nestedScrollView, getString(R.string.error_valid_email_password), Snackbar.LENGTH_LONG).show();
        }
    }


    /**
     * This method is to empty all input edit text
     */
    private void emptyInputEditText() {
        binding.textInputEditTextEmail.setText(null);
        binding.textInputEditTextPassword.setText(null);
    }

    private void showForgotPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
        builder.setTitle("Forgot Password");
        builder.setMessage("Enter your email to reset your password:");

        final EditText editTextEmail = new EditText(Login.this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        editTextEmail.setLayoutParams(layoutParams);

        builder.setView(editTextEmail);

        builder.setPositiveButton("Reset", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String email = editTextEmail.getText().toString().trim();
                // Perform the password reset logic here
                resetPassword(email);
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void resetPassword(String email) {
        // Retrieve the user from the SQLite database based on the email
        User user = databaseHelper.getUserByEmail(email);

        if (user != null) {
            showResetPasswordDialog(user);
        } else {
            // Show an error message if the user does not exist in the database
            Toast.makeText(Login.this, "User does not exist. Please enter a valid email.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showResetPasswordDialog(final User user) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
        builder.setTitle("Reset Password");
        builder.setMessage("Enter your new password:");

        final EditText editTextPassword = new EditText(Login.this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        editTextPassword.setLayoutParams(layoutParams);
        editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        builder.setView(editTextPassword);

        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String password = editTextPassword.getText().toString().trim();
                confirmPassword(user, password);
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void confirmPassword(User user, String password) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
        builder.setTitle("Confirm Password");
        builder.setMessage("Re-enter your new password:");

        final EditText editTextConfirmPassword = new EditText(Login.this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        editTextConfirmPassword.setLayoutParams(layoutParams);
        editTextConfirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        builder.setView(editTextConfirmPassword);

        builder.setPositiveButton("Reset", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String confirmPassword = editTextConfirmPassword.getText().toString().trim();

                if (confirmPassword.equals(password)) {
                    // Update the password for the user in the SQLite database
                    user.setPassword(password);
                    databaseHelper.updateUser(user);

                    // Show a success message to the user
                    Toast.makeText(Login.this, "Password reset successful.", Toast.LENGTH_LONG).show();
                } else {
                    // Show an error message if the passwords don't match
                    Toast.makeText(Login.this, "Passwords do not match. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }
}
