package com.mobilehybrid.openup.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.mobilehybrid.openup.R;
import com.mobilehybrid.openup.databinding.ActivityLoginBinding;
import com.mobilehybrid.openup.databinding.ActivityMainBinding;
import com.mobilehybrid.openup.helpers.SharePrefConfig;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    SharePrefConfig sharePrefConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        binding= ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        sharePrefConfig=new SharePrefConfig(this);

        binding.txtEmail.setText("Hello" +"\n"+ sharePrefConfig.getUser_email());
        binding.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                final EditText editText=new EditText(MainActivity.this);
                LinearLayout.LayoutParams layoutParams=new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT
                );
                editText.setLayoutParams(layoutParams);

                builder.setTitle("Are you sure want to logout ?")
                        .setView(editText)
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //finish();
                                sharePrefConfig.LogOut();
                                Intent intent=new Intent(MainActivity.this,Login.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);

                            }
                        })
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();

                            }
                        });
                //Creating dialog box
                builder.show();

            }
        });
    }
}