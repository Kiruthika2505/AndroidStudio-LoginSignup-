package com.mobilehybrid.openup.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.snackbar.Snackbar;
import com.mobilehybrid.openup.R;
import com.mobilehybrid.openup.databinding.ActivityLoginBinding;
import com.mobilehybrid.openup.databinding.ActivitySignupBinding;
import com.mobilehybrid.openup.helpers.InputValidation;
import com.mobilehybrid.openup.models.User;
import com.mobilehybrid.openup.sqlpart.DatabaseHelper;

public class Signup extends AppCompatActivity {

    ActivitySignupBinding binding;

    AppCompatActivity activity = Signup.this;
    private InputValidation inputValidation;
    private DatabaseHelper databaseHelper;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_signup);
        binding= ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initObjects();
        binding.appCompatButtonSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postDataToSQLite();
            }
        });
        binding.textViewLinkAlready.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Signup.this, Login.class);
                startActivity(i);
            }
        });
    }

    /**
     * This method is to initialize objects to be used
     */
    private void initObjects() {
        inputValidation = new InputValidation(activity);
        databaseHelper = new DatabaseHelper(activity);
        user = new User();
    }

    /**
     * This method is to validate the input text fields and post data to SQLite
     */
    private void postDataToSQLite() {
        if (!inputValidation.isInputEditTextFilled(binding.textInputName, binding.textInputLayoutName, getString(R.string.error_message_name))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(binding.textInputEditTextEmail, binding.textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextEmail(binding.textInputEditTextEmail, binding.textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(binding.textInputEditTextPassword, binding.textInputLayoutPassword, getString(R.string.error_message_password))) {
            return;
        }
        if (!inputValidation.isInputEditTextMatches(binding.textInputEditTextPassword, binding.textInputEditTextConPassword,
                binding.textInputLayoutConPassword, getString(R.string.error_password_match))) {
            return;
        }
        if (!databaseHelper.checkUser(binding.textInputEditTextEmail.getText().toString().trim())) {
            user.setName(binding.textInputName.getText().toString().trim());
            user.setEmail(binding.textInputEditTextEmail.getText().toString().trim());
            user.setPassword(binding.textInputEditTextPassword.getText().toString().trim());
            databaseHelper.addUser(user);
            // Snack Bar to show success message that record saved successfully
            Snackbar.make(binding.llSignup, getString(R.string.success_message), Snackbar.LENGTH_LONG).show();
            emptyInputEditText();
        } else {
            // Snack Bar to show error message that record already exists
            Snackbar.make(binding.llSignup, getString(R.string.error_email_exists), Snackbar.LENGTH_LONG).show();
        }
    }

    /**
     * This method is to empty all input edit text
     */
    private void emptyInputEditText() {
        binding.textInputName.setText(null);
        binding.textInputEditTextEmail.setText(null);
        binding.textInputEditTextPhone.setText(null);
        binding.textInputEditTextPassword.setText(null);
        binding.textInputEditTextConPassword.setText(null);
    }
}