package com.mobilehybrid.openup.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.mobilehybrid.openup.R;
import com.mobilehybrid.openup.helpers.SharePrefConfig;

public class Splash extends AppCompatActivity {

    Handler handler;
    SharePrefConfig sharePrefConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sharePrefConfig=new SharePrefConfig(this);
        handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (sharePrefConfig.getLoggedInStatus()){
                    Intent intent = new Intent(Splash.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Intent intent = new Intent(Splash.this, Login.class);
                    startActivity(intent);
                    finish();
                }
            }
        },3000);
    }
}