package com.mobilehybrid.openup.helpers;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class SharePrefConfig {

    private Activity activity;
    private Context context;
    private SharedPreferences sharedPreferences;
    private String packageName="com.mobilehybrid.openup";
    private int MOD_PRIVATE=0;
    SharedPreferences.Editor editor;
    private String USER_ID,user_name,user_email,user_addr,user_phone;
    private boolean isLoggedin;

    public SharePrefConfig(Activity activity)
    {
        this.activity=activity;
        sharedPreferences=this.activity.getSharedPreferences(packageName,MOD_PRIVATE);
        editor=sharedPreferences.edit();

    }
    public SharePrefConfig(Context context)
    {
        this.context=context;
        sharedPreferences=this.activity.getSharedPreferences(packageName,MOD_PRIVATE);
        editor=sharedPreferences.edit();
    }
    public void Set_UserID(String UserID)
    {
        editor.putString("USERID",UserID);
        editor.commit();
    }

    public String GetUserID()
    {
        USER_ID=sharedPreferences.getString("USERID", "");
        return USER_ID;
    }

    public void SetIsloogedIn(boolean logged)
    {
        editor.putBoolean("isloggedin",true);
        editor.commit();
    }

    public boolean getLoggedInStatus()
    {
        isLoggedin=sharedPreferences.getBoolean("isloggedin",false);
        return isLoggedin;

    }

    public void LogOut()
    {
        editor.clear();
        editor.commit();

    }

    public String getUser_name() {
        user_name=sharedPreferences.getString("u_name","");
        return user_name;
    }

    public void setUser_name(String name) {
        editor.putString("u_name",name);
        editor.commit();
        //this.user_name = user_name;
    }

    public String getUser_email() {
        user_email=sharedPreferences.getString("u_email","");
        return user_email;
    }

    public void setUser_email(String user_email) {
        editor.putString("u_email",user_email);
        editor.commit();
        //this.user_email = user_email;
    }
}
